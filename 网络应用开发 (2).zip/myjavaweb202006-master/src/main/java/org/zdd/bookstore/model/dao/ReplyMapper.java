package org.zdd.bookstore.model.dao;

import org.zdd.bookstore.common.utils.MyMapper;
import org.zdd.bookstore.model.entity.Reply;

public interface ReplyMapper extends MyMapper<Reply> {
}