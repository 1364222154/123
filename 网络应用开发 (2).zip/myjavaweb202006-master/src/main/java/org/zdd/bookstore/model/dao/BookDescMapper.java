package org.zdd.bookstore.model.dao;

import org.zdd.bookstore.common.utils.MyMapper;
import org.zdd.bookstore.model.entity.BookDesc;

public interface BookDescMapper extends MyMapper<BookDesc> {
}