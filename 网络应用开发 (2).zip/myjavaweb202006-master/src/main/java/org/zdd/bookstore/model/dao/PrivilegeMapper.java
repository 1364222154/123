package org.zdd.bookstore.model.dao;

import org.zdd.bookstore.common.utils.MyMapper;
import org.zdd.bookstore.model.entity.Privilege;

public interface PrivilegeMapper extends MyMapper<Privilege> {
}