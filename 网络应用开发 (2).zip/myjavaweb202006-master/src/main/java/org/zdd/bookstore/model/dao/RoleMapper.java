package org.zdd.bookstore.model.dao;

import org.zdd.bookstore.common.utils.MyMapper;
import org.zdd.bookstore.model.entity.Role;

public interface RoleMapper extends MyMapper<Role> {
}